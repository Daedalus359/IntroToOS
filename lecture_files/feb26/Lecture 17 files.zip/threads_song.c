// Chris Fietkiewicz (chris.fietkiewicz@case.edu)
// Displays text for a song.

#include <pthread.h>
#include <stdio.h>

char lyrics[100];

void *child(); /* the thread */

int main(int argc, char *argv[])
{
	pthread_t tid; /* the thread identifier */
	pthread_attr_t attr; /* set of attributes for the thread */
	/* get the default attributes */
	pthread_attr_init(&attr);
	/* create the thread */
	sprintf(lyrics, "Shine on...\n");
	pthread_create(&tid, &attr, child, NULL);
	/* now wait for the thread to exit */
	pthread_join(tid, NULL);
	printf("Parent says... ARE WE!!!\n");
	sleep(3);

	sprintf(lyrics, "Your brave sons and daughters...\n");
	pthread_create(&tid, &attr, child, NULL);
	/* now wait for the thread to exit */
	pthread_join(tid, NULL);
	printf("Parent says... THE START!!!\n");
	sleep(3);

	sprintf(lyrics, "Shine on...\n");
	pthread_create(&tid, &attr, child, NULL);
	/* now wait for the thread to exit */
	pthread_join(tid, NULL);
}

void *child() 
{
	printf("%s\n", lyrics);
	sleep(5);
}
